/* tslint:disable */
require("./PasscodeModal.module.css");
const styles = {
  passcodeModalContainer: 'passcodeModalContainer_8d16d929',
  header: 'header_8d16d929',
  closeButton: 'closeButton_8d16d929',
  body: 'body_8d16d929',
  buttons: 'buttons_8d16d929'
};

export default styles;
/* tslint:enable */